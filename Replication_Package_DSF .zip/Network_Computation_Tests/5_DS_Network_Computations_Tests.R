#A NETWORK ANALYSIS OF GLOBAL TRADE, TERMS OF TRADE AND INCOME
#DIEGO SANTANA FOMBONA
#NETWORK COMPUTATIONS TESTS

#SCRIPT 5: NETOWRK COMPUTATIONS TESTS-----

#Install and Load Packages------

##Install imfr package (out of CRAN)-----
install.packages("devtools")
require(devtools)
install_github("christophergandrud/imfr")

##Install packages----------
if(!require(readxl)) install.packages("readxl")
if(!require(tidyverse)) install.packages("tidyverse")
if(!require(imfr)) install.packages("imfr")
if(!require(rdbnomics)) install.packages("rdbnomics")
if(!require(countrycode)) install.packages("countrycode")
if(!require(igraph)) install.packages("igraph")
if(!require(BBmisc)) install.packages("BBmisc")
if(!require(ggraph)) install.packages("ggraph")
if(!require(graphlayouts)) install.packages("graphlayouts")
if(!require(corrplot)) install.packages("corrplot")
if(!require(circlize)) install.packages("circlize")

if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("ComplexHeatmap")

if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
BiocManager::install(version = "3.14")
BiocManager::install("ComplexHeatmap")
if(!require(grid)) install.packages("grid")
if(!require(gridBase)) install.packages("gridBase")
if(!require(rticles)) install.packages("rticles")

##Load packages--------
library(readxl)
library(tidyverse)
library(imfr)
library(rdbnomics)
library(countrycode)
library(igraph)
library(BBmisc)
library(ggraph)
library(graphlayouts)
library(corrplot)
library(circlize)
library(ComplexHeatmap)
library(grid)
library(gridBase)
library(rticles)

#Select Test by removing "#" for Test_1 or Test_2

#imf_dots <- read_excel("Test_1.xlsx")
imf_dots <- read_excel("Test_2.xlsx")

#INFLATION ADJUSTED NETWORK ANALYSIS----

##Tibbles to save results-----

#Netowrk atributes (Network as a whole)
imf_network_scores_cons <- tibble()

#Jusrisdiction attributes (Measures for individual countries)
imf_jurisdiction_scores_cons <- tibble()

#Graph list
graph_list <- list()

#Graph year identifier
graph_year <- 0

##Loop to analyse graphs----
for(i in unique(imf_dots$year)){
  
  #Graph construction
  
  #Edges
  imf_edges <- imf_dots %>%
    filter(year == i) %>%
    rename(from = jurisdiction_iso3, to = counterpart_iso3, weight = exports_cons) %>%
    select(from, to, weight)
  
  imf_edges <- imf_edges %>% filter(to != "CSH")
  imf_edges <- imf_edges %>% filter(to != "DDD")
  imf_edges <- imf_edges %>% filter(to != "SCG")
  imf_edges <- imf_edges %>% filter(to != "ANT")
  imf_edges <- imf_edges %>% filter(to != "SUN")
  imf_edges <- imf_edges %>% filter(to != "YAR")
  imf_edges <- imf_edges %>% filter(to != "YMD")
  imf_edges <- imf_edges %>% filter(to != "YUG")
  
  imf_edges <- imf_edges %>% filter(from != "CSH")
  imf_edges <- imf_edges %>% filter(from != "DDD")
  imf_edges <- imf_edges %>% filter(from != "SCG")
  imf_edges <- imf_edges %>% filter(from != "ANT")
  imf_edges <- imf_edges %>% filter(from != "SUN")
  imf_edges <- imf_edges %>% filter(from != "YAR")
  imf_edges <- imf_edges %>% filter(from != "YMD")
  imf_edges <- imf_edges %>% filter(from != "YUG")
  #Nodes
  imf_nodes <- imf_dots %>%
    filter(year == i) %>% 
    rename(vertices = jurisdiction_iso3) %>%
    select(vertices) %>% unique()
  
  #Network
  imf_graph <- graph_from_data_frame(d = imf_edges, vertices = imf_nodes, directed = TRUE)
  
  
  #Network Attributes
  imf_graph <- imf_graph %>%
    set.graph.attribute("year", value = i) %>%
    set.edge.attribute("n_weight", value = E(imf_graph)$weight/max(E(imf_graph)$weight)) %>%
    set.edge.attribute("dist_weight", value = 1/E(imf_graph)$weight) %>%
    delete.vertices(c(names(which(igraph::degree(imf_graph)==0))))
  
  ##Network Measures----
  
  #Save network features
  imf_features <- tibble(Year = i, #Year
                         Nodes = gorder(imf_graph), #Number of nodes
                         Edges = gsize(imf_graph), #Number of links
                         Density = edge_density(imf_graph), #Density
                         Mean_distance = mean_distance(imf_graph, directed = TRUE, weights = NA), #Mean Distance
                         Transitivity_uw = transitivity(imf_graph, weights = NA), #Transitivity (Unweighted)
                         Transitivity_w = transitivity(imf_graph, weights = E(imf_graph)$dist_weight), #Transitivity (Weighted)
                         Reciprocity = reciprocity(imf_graph), #Reciprocity
                         Diameter_uw = diameter(imf_graph, directed = TRUE, weights = NA), #Diameter (Unweighted)
                         Diameter_w = diameter(imf_graph, directed = TRUE, weights = E(imf_graph)$dist_weight)) #Diameter (Weighted)

  
  #Create network results
  imf_network_scores_cons <- rbind(imf_network_scores_cons, imf_features)
  
  #Erase features
  rm(imf_features)
  
  ##Jurisdiction measures -----
  
  #Intermediate tibble to save results
  imf_results <- tibble()
  
  ###Strength-----
  
  #Out
  V(imf_graph)$strength_out <- strength(imf_graph, mode = "out")
  
  #In
  V(imf_graph)$strength_in <- strength(imf_graph, mode = "in")
  
  #Total
  V(imf_graph)$strength_total <- strength(imf_graph, mode = "total")
  
  ###Centrality-----
  
  ####Degree----
  
  #Out-degree
  V(imf_graph)$degree_out <- igraph::degree(imf_graph, mode = "out")
  
  #In-degree
  V(imf_graph)$degree_in <- igraph::degree(imf_graph, mode = "in")
  
  ####Closeness----
  
  #Un-Weighted
  V(imf_graph)$closeness_uw <- closeness(imf_graph, mode = "all", weights = NA)
  
  #Weighted
  V(imf_graph)$closeness_w <- closeness(imf_graph, mode = "all", weights = E(imf_graph)$dist_weight)
  
  ####Betwenness----
  
  #Un-Weighted
  V(imf_graph)$betweenness_uw <- betweenness(imf_graph, weights = NA)
  
  #Weighted
  V(imf_graph)$betweenness_w <- betweenness(imf_graph, weights = E(imf_graph)$dist_weight)
  
  ####Eigenvector----
  
  #Un-Weighted
  V(imf_graph)$eigen_vector_uw <- eigen_centrality(imf_graph, directed = TRUE, weights = NA)$vector
  
  #Weighted
  V(imf_graph)$eigen_vector_w <- eigen_centrality(imf_graph, directed = TRUE, weights = E(imf_graph)$weight)$vector
  
  ####Alpha----
  
  #Un-Weighted
  V(imf_graph)$alpha_uw <- alpha_centrality(imf_graph, alpha = (1/eigen_centrality(imf_graph, directed = TRUE, weights = NA)$value)*0.5, weights = NA)
  
  #Weighted
  V(imf_graph)$alpha_w <- alpha_centrality(imf_graph, alpha = (1/eigen_centrality(imf_graph, directed = TRUE, weights = E(imf_graph)$weight)$value)*0.5)
  
  ####Page Rank----
  V(imf_graph)$page_rank <- page_rank(imf_graph, directed = TRUE)$vector
  
  
  #Add results
  imf_results <- igraph::as_data_frame(imf_graph, what = "vertices") %>% 
    mutate(year = i) %>%
    select(year, everything())
  
  imf_jurisdiction_scores_cons <- rbind(imf_jurisdiction_scores_cons, imf_results)
  
  #Erase intermediate tibble
  rm(imf_results)
  
  #Delete nodes and edges
  rm(imf_edges)
  rm(imf_nodes)
  
  ##Graph list----
  graph_year <- graph_year + 1
  graph_list[[graph_year]] <- imf_graph 
  names(graph_list)[graph_year] <- i
  
}

#Order imf network scores 
imf_network_scores_cons <- imf_network_scores_cons[order(imf_network_scores_cons$Year),]

#INDICES----

##Annual normalization -------
imf_jurisdiction_scores_cons_normalized <- tibble()

for(i in unique(imf_jurisdiction_scores_cons$year)){
  
  temporary_dataframe <- imf_jurisdiction_scores_cons %>% filter(year == i) %>%
    mutate(strength_out_norm = BBmisc::normalize(strength_out, method = "range",  range = c(0 , 1)),
           strength_in_norm = BBmisc::normalize(strength_in, method = "range",  range = c(0 , 1)),
           strength_total_norm = BBmisc::normalize(strength_total, method = "range",  range = c(0 , 1)),
           degree_out_norm = BBmisc::normalize(degree_out, method = "range",  range = c(0 , 1)), 
           degree_in_norm = BBmisc::normalize(degree_in, method = "range",  range = c(0 , 1)), 
           closeness_uw_norm = BBmisc::normalize(closeness_uw, method = "range",  range = c(0 , 1)),
           closeness_w_norm = BBmisc::normalize(closeness_w, method = "range",  range = c(0 , 1)),
           betweenness_uw_norm = BBmisc::normalize(betweenness_uw, method = "range",  range = c(0 , 1)),
           betweenness_w_norm = BBmisc::normalize(betweenness_w, method = "range",  range = c(0 , 1)),
           alpha_uw_norm = BBmisc::normalize(alpha_uw, method = "range",  range = c(0 , 1)),
           alpha_w_norm = BBmisc::normalize(alpha_w, method = "range",  range = c(0 , 1))) %>%
    mutate(index_str = rowMeans(select(., c(strength_out_norm, strength_in_norm, strength_total_norm))),
           index_uw = rowMeans(select(., c(degree_out_norm, degree_in_norm, closeness_uw_norm,  betweenness_uw_norm, eigen_vector_uw, alpha_uw_norm))),
           index_w = rowMeans(select(., c(closeness_w_norm,  betweenness_w_norm, eigen_vector_w, alpha_w_norm)))) %>%
    mutate(index_final_norm = rowMeans(select(., c(index_str, index_uw, index_w)))*100,
           index_rank_norm = rank(desc(index_final_norm))) %>%
    select(year, name, 
           strength_out_norm, strength_in_norm, strength_total_norm, 
           degree_out_norm, degree_in_norm, closeness_uw_norm, closeness_w_norm,
           betweenness_uw_norm, betweenness_w_norm, eigen_vector_uw, eigen_vector_w, 
           alpha_uw_norm, alpha_w_norm, 
           index_str, index_uw, index_w, index_final_norm, index_rank_norm)
  
  imf_jurisdiction_scores_cons_normalized <- rbind(imf_jurisdiction_scores_cons_normalized, temporary_dataframe)
  
}

##Panel Normalization (Percentile)------

imf_results <- imf_jurisdiction_scores_cons %>% 
  mutate(strength_out_per = percent_rank(strength_out),
         strength_in_per = percent_rank(strength_in),
         strength_total_per = percent_rank(strength_total),
         degree_out_per = percent_rank(degree_out), 
         degree_in_per = percent_rank(degree_in), 
         closeness_uw_per = percent_rank(closeness_uw),
         closeness_w_per = percent_rank(closeness_w),
         betweenness_uw_per = percent_rank(betweenness_uw),
         betweenness_w_per = percent_rank(betweenness_w),
         alpha_uw_per = percent_rank(alpha_uw),
         alpha_w_per = percent_rank(alpha_w),
         eigen_vector_uw_per = percent_rank(eigen_vector_uw),
         eigen_vector_w_per = percent_rank(eigen_vector_w)) %>%
  mutate(index_str_per = rowMeans(select(., c(strength_out_per, strength_in_per, strength_total_per))),
         index_uw_per = rowMeans(select(., c(degree_out_per, degree_in_per, closeness_uw_per, betweenness_uw_per, eigen_vector_uw_per, alpha_uw_per))),
         index_w_per = rowMeans(select(., c(closeness_w_per,  betweenness_w_per, eigen_vector_w_per, alpha_w_per)))) %>%
  mutate(index_final_per = rowMeans(select(., c(index_str_per, index_uw_per, index_w_per)))*100) %>%
  select(year, name,
         strength_out_per, strength_in_per, strength_total_per, 
         degree_out_per, degree_in_per, 
         closeness_uw_per, closeness_w_per,
         betweenness_uw_per, betweenness_w_per,
         eigen_vector_uw_per, eigen_vector_w_per, 
         alpha_uw_per, alpha_w_per, 
         index_str_per, index_uw_per, index_w_per, index_final_per)


imf_jurisdiction_scores_cons_percentil <- tibble()

#Saving dataframe
for(i in unique(imf_dots$year)){
  
  temporary_dataframe <- imf_results %>% filter(year == i) %>%
    mutate(index_rank_per = rank(desc(index_final_per)))
  
  imf_jurisdiction_scores_cons_percentil <- rbind(imf_jurisdiction_scores_cons_percentil, temporary_dataframe)
  
  rm(temporary_dataframe)
  
}


rm(imf_results)

#Principal component Analysis##

#Create new column with country/year
imf_jurisdiction_scores_cons_percentil_mod <- imf_jurisdiction_scores_cons_percentil %>% mutate(year_name = with(., paste0(year,name)))


#data_name <- imf_jurisdiction_scores_cons_percentil_mod %>% select(.,c(year_name, strength_out_per, strength_in_per, strength_total_per,
#                                                          degree_out_per, degree_in_per, closeness_uw_per, betweenness_uw_per, 
#                                                          eigen_vector_uw_per, alpha_uw_per, closeness_w_per,  
#                                                          betweenness_w_per, eigen_vector_w_per, alpha_w_per 
#                                                          ))


#Data for PCA
data <- imf_jurisdiction_scores_cons_percentil_mod %>% select(.,c( strength_out_per, strength_in_per, strength_total_per,
                                                                   degree_out_per, degree_in_per, closeness_uw_per, betweenness_uw_per, 
                                                                   eigen_vector_uw_per, alpha_uw_per, closeness_w_per,  
                                                                   betweenness_w_per, eigen_vector_w_per, alpha_w_per 
))

#data <- imf_jurisdiction_scores_cons_percentil_mod %>% select(.,c( strength_out_per, strength_in_per,
#                                                                   degree_out_per, degree_in_per, closeness_uw_per, betweenness_uw_per, 
#                                                                   eigen_vector_uw_per, alpha_uw_per, closeness_w_per,  
#                                                                  betweenness_w_per, eigen_vector_w_per, alpha_w_per 
#))

#data <- imf_jurisdiction_scores_cons_percentil_mod %>% select(.,c( strength_out_per, strength_in_per, 
#                                                                   eigen_vector_uw_per, alpha_uw_per, closeness_w_per,  
#                                                                   betweenness_w_per, eigen_vector_w_per, alpha_w_per 
#))

#Assignme country and year to the PCA data
rownames(data) <- c(imf_jurisdiction_scores_cons_percentil_mod$year_name)

#Run PCA  
index_pc <- prcomp(data, center = FALSE, scale. = TRUE) 

#Summary and rotation of the PCA
summary(index_pc)
index_pc$x[,1]
index_pc$rotation

#Normalize PCA
index_pc_norm <- BBmisc::normalize(index_pc$x[,1], method = "range",  range = c(1 , 0))

#Safe values for the PCA
imf_jurisdiction_scores_cons_percentil_mod <- imf_jurisdiction_scores_cons_percentil_mod %>% mutate(., index_pc_attp = index_pc_norm)

#Calculate network average PCA
i <- 2021
avg_network_index_pca <- tibble()
for(i in unique(imf_dots$year)){
  vector_temporary <- imf_jurisdiction_scores_cons_percentil_mod %>% filter(., year == i) %>% select(index_pc_attp)
  value <- mean(vector_temporary$index_pc_attp)
  avg_network_index_pca <- rbind(avg_network_index_pca, value)
}

#Calculate network average old index
avg_network_index_avg <- tibble()
for(i in unique(imf_dots$year)){
  vector_temporary <- imf_jurisdiction_scores_cons_percentil_mod %>% filter(., year == i) %>% select(index_final_per)
  value <- mean(vector_temporary$index_final_per)
  avg_network_index_avg <- rbind(avg_network_index_avg, value)
}

avg_network_index_pca <- cbind( unique(imf_dots$year), avg_network_index_pca)

avg_network_index_avg <- cbind( unique(imf_dots$year), avg_network_index_avg)

colnames(avg_network_index_pca) <- c("Year", "index_pca")
colnames(avg_network_index_avg) <- c("Year", "index_avg")

imf_network_scores_cons <- merge(imf_network_scores_cons, avg_network_index_pca,  by =("Year") )

imf_network_scores_cons <- merge(imf_network_scores_cons, avg_network_index_avg,  by =("Year") )













